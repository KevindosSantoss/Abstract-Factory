package refactoring_guru.abstract_factory.example.checkboxes;

/**
 * Caixas de seleção são a segunda família de produtos. Possui as mesmas variantes dos botões.
 */
public interface Checkbox {
    void paint();
}