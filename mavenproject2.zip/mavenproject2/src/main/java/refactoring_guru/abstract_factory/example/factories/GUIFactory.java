package refactoring_guru.abstract_factory.example.factories;

import refactoring_guru.abstract_factory.example.buttons.Button;
import refactoring_guru.abstract_factory.example.checkboxes.Checkbox;

/**
 * A fábrica abstrata conhece todos os tipos de produtos (abstratos).
 */
public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}